/******************************************************************************
* File Name: dtmf.c
*
* Author: Carlos Barrios
*
* Created for CMPR-271 on: Nov. 1, 2019
*
* Purpose: Takes arguments from the command line and generates a Window's
* wave format file composed of DTMF tones.
*
******************************************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "fwm7941_proj4_wavefile.h"
#include "fwm7941_proj4_dtmf.h"
//#include "wavefile.h" // specific for dealing with .wav files
//#include "dtmf.h"     // specific to your application - function prototypes
// for any functions you write should go in this file.

#define DIG 13
#define TONE 13
#define BIT 64
#define AMPLITUDE 16382
#define SAMPLE_RATE 44100

int main (int argc, const char* argv[])
{
    if (argc != 4)
    {
        printf("Error: Improper number of arguments.");

        return -1;
    }

    // declare local variables, such as
    int freq1;
    int freq2;

    float length;
    int i;
    int dig;



    FILE *fptr = fopen(argv[1] , "wb");

                if (fptr == NULL)
                {
                    printf("Error: File could not be created or opened.");

                    return -1;
                }


            length = atof(argv[2]);

                if (length < 0.1 || length > 1)
                {
                    puts("Error: Tone length too short or too long.");

                    return -1;
                }


        for (dig = 0; *(argv[3]+dig) != '\0'; dig++)
        {
            switch (*(argv[3]+dig))
            {
                case '0':
                    freq1 = 1336;
                    freq2 = 941;
                    break;
                case '1':
                    freq1 = 1209;
                    freq2 = 697;
                    break;
                case '2':
                    freq1 = 1336;
                    freq2 = 697;
                    break;
                case '3':
                    freq1 = 1477;
                    freq2 = 697;
                    break;
                case '4':
                    freq1 = 1209;
                    freq2 = 770;
                    break;
                case '5':
                    freq1 = 1336;
                    freq2 = 770;
                    break;
                case '6':
                    freq1 = 1477;
                    freq2 = 770;
                    break;
                case '7':
                    freq1 = 1209;
                    freq2 = 852;
                    break;
                case '8':
                    freq1 = 1336;
                    freq2 = 852;
                    break;
                case '9':
                    freq1 = 1477;
                    freq2 = 852;
                    break;
                case '*':
                    freq1 = 1209;
                    freq2 = 941;
                    break;
                case '#':
                    freq1 = 1336;
                    freq2 = 1477;
                    break;
                case '-':
                    freq1 = 0;
                    freq2 = 0;
                    break;
                break;
                default: printf("Error: Wrong Number, Try Again.");

                return -1;
            }
        }

    for (i = 1; i < argc; i++)
    {
        printf("%s%s" , argv[i], (i < argc - 1) ? " " : "");
        printf("\n");
    }

    // variable and pointer to WAVEFILE structure
    // pointers to data samples
    // variables used for user input, etc


    // check if user typed 4 arguments in the command line
    // using argc
    // if not, show user proper format


    // Check for valid numbers and symbols in phone number and tonelength
    // using argv[]
    // if not, show user proper format


    // change the string of the tone length to a numerical value

    // check for valid tone lengths
    // if not, show user proper format

    // Now, either a) declare a variable of WAVEFILE datatype to
    // hold the 'header' of the wavefile,
    // or b) allocate memory for the 'header' of the wavefile
    // using malloc()

    WAVEFILE *headerPtr;

     headerPtr = malloc(sizeof(WAVEFILE));

        if (malloc(sizeof(WAVEFILE)) == NULL)
        {
            printf("Error, WAVEFILE not properly allocated.");

            return -1;

        }

    headerPtr->BitsPerSample = 16;

    headerPtr->NumChannels = 1;

    headerPtr->SubChunk2Size = (SAMPLE_RATE * length * dig) * headerPtr->NumChannels * headerPtr->BitsPerSample/8;

    headerPtr->SubChunk1Size = 16;

    headerPtr->ChunkID[0] = 0x52;

    headerPtr->ChunkID[1] = 0x49;

    headerPtr->ChunkID[2] = 0x46;

    headerPtr->ChunkID[3] = 0x46;


    headerPtr->ChunkSize = 4 + (8+headerPtr->SubChunk1Size) + (8+headerPtr->SubChunk2Size);


    headerPtr->Format[0] = 0x57;

    headerPtr->Format[1] = 0x41;

    headerPtr->Format[2] = 0x56;

    headerPtr->Format[3] = 0x45;


    headerPtr->SubChunk1ID[0] = 0x66;

    headerPtr->SubChunk1ID[1] = 0x6D;

    headerPtr->SubChunk1ID[2] = 0x74;

    headerPtr->SubChunk1ID[3] = 0x20;


    headerPtr->AudioFormat = 1;


    headerPtr->SampleRate = SAMPLE_RATE;


    headerPtr->ByteRate = headerPtr->SampleRate * headerPtr->NumChannels * headerPtr->BitsPerSample/8;


    headerPtr->BlockAlign = headerPtr->NumChannels *  headerPtr->BitsPerSample/8;


    headerPtr->SubChunk2ID[0] = 0x64;

    headerPtr->SubChunk2ID[1] = 0x61;

    headerPtr->SubChunk2ID[2] = 0x74;

    headerPtr->SubChunk2ID[3] = 0x61;




            // and check it was properly allocated (did malloc return NULL?)

    // allocate memory for the data in the file (for the samples)


    // using malloc()

    short *dataSamplesPtr;

    dataSamplesPtr = malloc(length * dig * SAMPLE_RATE * BYTES_PER_SAMPLE);

    // number of bytes will depend on:
    // 1) number of digits in number
    // 2) toneLength per digit
    // 3) SAMPLE_RATE - defined in wavefile.h
    // 4) BYTES_PER_SAMPLE - defined in wavefile.h

     if (dataSamplesPtr == NULL)
        {
            printf("Error, dataSamplePtr not properly allocated.");

            return -1;

        }

    // and check it was properly allocated (did malloc return NULL?)

    // fill in the wavefile-header structure (members) into the allocated memory,
    // using dot (.) or arrow (->) operators
    // (use dot if you created a WAVEFILE variable, use arrow if you used malloc and have a pointer)

    // open/create the file using fopen(), and check it was properly opened

    // create the data samples, populating the allocated data memory
    int SampleOffset = 0;
    double sampleValue;

        for (dig = 0; *(argv[3]+dig) != '\0'; dig++)
       {
            switch (*(argv[3]+dig))
            {
                case '0':
                    freq1 = 1336;
                    freq2 = 941;
                    break;
                case '1':
                    freq1 = 1209;
                    freq2 = 697;
                    break;
                case '2':
                    freq1 = 1336;
                    freq2 = 697;
                    break;
                case '3':
                    freq1 = 1477;
                    freq2 = 697;
                    break;
                case '4':
                    freq1 = 1209;
                    freq2 = 770;
                    break;
                case '5':
                    freq1 = 1336;
                    freq2 = 770;
                    break;
                case '6':
                    freq1 = 1477;
                    freq2 = 770;
                    break;
                case '7':
                    freq1 = 1209;
                    freq2 = 852;
                    break;
                case '8':
                    freq1 = 1336;
                    freq2 = 852;
                    break;
                case '9':
                    freq1 = 1477;
                    freq2 = 852;
                    break;
                case '*':
                    freq1 = 1209;
                    freq2 = 941;
                    break;
                case '#':
                    freq1 = 941;
                    freq2 = 1477;
                    break;
                case '-':
                    freq1 = 0;
                    freq2 = 0;
                    break;
                break;
            }
            for (size_t sampleNum = 0; sampleNum < SAMPLE_RATE * length; sampleNum++)
            {

                sampleValue = AMPLITUDE * (sin(sampleNum * freq1 * 2 * 3.14159 / SAMPLE_RATE) + sin(sampleNum * freq2 * 2 * 3.14159 / SAMPLE_RATE));
                *(dataSamplesPtr + SampleOffset) = sampleValue;
                SampleOffset++;
            }
        }

    // write (copy) the wavefile-header of the wavefile, from allocated
    // memory, into the file, and check it wrote properly
    fwrite(headerPtr, sizeof(WAVEFILE), 1, fptr);

    // write (copy) the data-samples of the wavefile, from allocated
    // memory, into the file, and check it wrote properly
    fwrite(dataSamplesPtr, (length * dig * SAMPLE_RATE * BYTES_PER_SAMPLE), 1, fptr);
    // close the file
    fclose(fptr);

    free(headerPtr);
    free(dataSamplesPtr);

    // free all allocated memory

    return (0);


}




/******************************************************************************
* Function Name: show_usage
*
* Purpose: Shows user how to use this program
*
* Arguments: None
*
* Returns: Nothing
*
******************************************************************************/
void show_usage(void)
{
   printf("\nUsage: ./dtmf.exe X Y Z\n\n");
   printf(" Where X is the name of the Wave file to create\n");
   printf(" Where Y is the duration (in seconds) of each dtmf tone, valid range is 0.1 - 1.0\n");
   printf(" Where Z is the string of digits to create tones for, valid\n");
   printf("    digits are 0-9, #, * and - for a duration of silence\n");
   printf("\nExample: ./dtmf.exe wavy.wav 0.3 123-3831\n");
}


// $ gcc -std=c99 -Wall -Wextra -pedantic -lm fwm7941_proj4_dtmf.c -o fwm7941_proj4_dtmf.exe
